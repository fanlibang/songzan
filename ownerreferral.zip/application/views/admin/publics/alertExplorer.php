<h2 class="contentTitle">推荐浏览器</h2>
<div class="pageContent">
    <div class="pageFormContent" layoutH="97">
        <center>
            <a href="http://www.firefox.com.cn/download/" target="_blank" title="点击下载火狐浏览器">
                <img src="<?php echo HTTP_HOST_PUBLIC; ?>Admin/Image/firefox.png" title="火狐浏览器下载">
            </a>
            <a href="http://www.google.cn/intl/zh-CN/chrome/" target="_blank" title="点击下载Chrome浏览器" style="margin-left: 50px">
                <img src="<?php echo HTTP_HOST_PUBLIC; ?>Admin/Image/chrome.png" title="Chrome浏览器下载">
            </a>
            <a href="http://www.apple.com/cn/safari/" target="_blank" title="点击下载safari浏览器" style="margin-left: 50px">
                <img src="<?php echo HTTP_HOST_PUBLIC; ?>Admin/Image/safari.png" title="Safari浏览器下载">
            </a>
        </center>
    </div>
    <div class="formBar">
        <ul>
            <li><div class="button"><div class="buttonContent"><button class="close" type="button">关闭</button></div></div></li>
        </ul>
    </div>
</div>