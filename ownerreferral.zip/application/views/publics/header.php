<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=750, user-scalable=no, target-densitydpi=device-dpi">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="format-detection" content="telephone=no, email=no"/>
    <meta name="msapplication-tap-highlight" content="no">
    <meta content="<?= STATIC_ASSETS ?>images/logo.png" name="msapplication-TileImage">
    <link href="<?= STATIC_ASSETS ?>images/logo.png" rel="apple-touch-icon" sizes="152x152">
    <title>荐入佳境 共揽胜景</title>
    <link href="<?= STATIC_ASSETS ?>css/base.css?t=<?=time()?>" rel="stylesheet" type="text/css">
    <script src="<?= STATIC_ASSETS ?>js/jquery.min.js" type="text/javascript"></script>
    <script src="<?= STATIC_ASSETS ?>js/main.js?t=<?=time()?>" type="text/javascript"></script>
</head>
<body>