<?php include 'header.php';//页面顶部 ?>
<?php echo isset($main_html) ? $main_html : '';//页面主体 ?>
<?php include 'footer.php';//页面顶部 ?>
