<?php
	echo phpinfo();
?>
